var admin;
var name = "Василий";
alert("Имя админа: " + (admin = name));

alert("Выражение 1000 + \"108\" равно " + 1000 + "108");